# 🍽️ FamFood - Family Meal Planner

Plan your family meals easily and save time and money.

## 🌍 Languages
- 🇪🇸 Spanish
- 🇬🇧 English  
- 🇫🇷 French
- 🇩🇪 German

## ✨ Features

- 📅 **Weekly Menu Planner** - Drag & drop recipes to plan your week
- 🍳 **100+ Recipes** - Family recipes from 4 countries
- 🛒 **Auto Shopping List** - Generated from your menu
- 👨‍👩‍👧‍👦 **Family Profile** - People, allergies, preferences
- 🎲 **Auto Suggest** - Generate random menus with one click

## 🚀 Quick Start

```bash
pip install -r requirements.txt
streamlit run app.py
```

## 📱 Deploy to Streamlit Cloud

1. Fork this repository
2. Go to [share.streamlit.io](https://share.streamlit.io)
3. Connect your GitHub
4. Select this repo and `app.py`
5. Deploy!

## 💰 Pricing Model

- **Free**: 50 recipes, basic features
- **Premium** (€3.99/mo): 500+ recipes, AI suggestions
- **Family** (€5.99/mo): Multiple profiles, shared lists

## 📄 License

MIT License
