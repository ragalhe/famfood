# 🍽️ FamFood PRO - Smart Family Meal Planner

<p align="center">
  <img src="https://img.shields.io/badge/Version-2.0-orange" alt="Version">
  <img src="https://img.shields.io/badge/Languages-4-green" alt="Languages">
  <img src="https://img.shields.io/badge/Recipes-100+-blue" alt="Recipes">
  <img src="https://img.shields.io/badge/License-MIT-yellow" alt="License">
</p>

## 🌍 Multi-Language Support

| Language | Flag | Status |
|----------|------|--------|
| Spanish | 🇪🇸 | ✅ Full support |
| English | 🇬🇧 | ✅ Full support |
| French | 🇫🇷 | ✅ Full support |
| German | 🇩🇪 | ✅ Full support |

**All recipes, UI elements, and content are fully translated!**

## ✨ Features

### 📅 Weekly Menu Planner
- Visual drag & drop calendar
- Lunch and dinner for 7 days
- Auto-generate menu with one click
- Copy previous week's menu

### 🍳 Recipe Database
- 100+ family-friendly recipes
- Full nutrition info (calories, proteins, carbs, fats)
- Difficulty levels and prep times
- Filter by category, time, or ingredients
- All recipes translated to 4 languages

### 🛒 Smart Shopping List
- Auto-generated from your menu
- Organized by supermarket aisles
- Share via WhatsApp
- Track bought items
- Estimated cost calculator

### 🤖 AI Assistant
- "What's in my fridge?" feature
- Smart recipe suggestions
- Find healthier/cheaper/faster alternatives
- Personalized recommendations

### 👨‍👩‍👧‍👦 Family Profile
- Configure number of adults/children
- Set weekly budget
- Manage allergies and intolerances
- Food preferences (vegetarian, no pork, etc.)

### ⭐ Premium Features
- 500+ exclusive recipes
- Unlimited AI suggestions
- Complete nutrition tracking
- Ad-free experience

## 🚀 Quick Start

### Local Installation

```bash
# Clone repository
git clone https://github.com/yourusername/famfood.git
cd famfood

# Install dependencies
pip install -r requirements.txt

# Run the app
streamlit run app.py
```

### Deploy to Streamlit Cloud

1. Fork this repository
2. Go to [share.streamlit.io](https://share.streamlit.io)
3. Connect your GitHub account
4. Select this repo and `app.py`
5. Click Deploy!

## 📱 Screenshots

```
┌─────────────────────────────────────┐
│  🍽️ FamFood                        │
│  Your smart family meal planner    │
├─────────────────────────────────────┤
│                                     │
│  MON  TUE  WED  THU  FRI  SAT  SUN │
│  ┌──┐ ┌──┐ ┌──┐ ┌──┐ ┌──┐ ┌──┐ ┌──┐│
│  │🥚│ │🥗│ │🍗│ │🐟│ │🍕│ │🥘│ │🍖││
│  └──┘ └──┘ └──┘ └──┘ └──┘ └──┘ └──┘│
│  ┌──┐ ┌──┐ ┌──┐ ┌──┐ ┌──┐ ┌──┐ ┌──┐│
│  │🍲│ │🍝│ │🥣│ │🍜│ │🌯│ │🍔│ │🥗││
│  └──┘ └──┘ └──┘ └──┘ └──┘ └──┘ └──┘│
│                                     │
│  🔥 4,200 kcal  💰 ~67€  ⏱️ 5.2h   │
└─────────────────────────────────────┘
```

## 💰 Business Model

| Plan | Price | Features |
|------|-------|----------|
| **Free** | €0 | 50 recipes, basic features |
| **Premium** | €3.99/mo | 500+ recipes, AI assistant |
| **Family** | €5.99/mo | Multiple profiles, shared lists |

## 🛠️ Tech Stack

- **Frontend**: Streamlit
- **Language**: Python 3.9+
- **Styling**: Custom CSS
- **Deployment**: Streamlit Cloud

## 📂 Project Structure

```
famfood_pro/
├── app.py                 # Main application
├── requirements.txt       # Dependencies
├── README.md             # Documentation
└── .streamlit/
    └── config.toml       # Streamlit config
```

## 🔮 Roadmap

- [ ] Mobile app (React Native)
- [ ] Barcode scanner for shopping
- [ ] Integration with smart fridges
- [ ] Voice assistant support
- [ ] Meal prep mode
- [ ] Family sync feature

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📄 License

MIT License - see LICENSE file for details.

## 👨‍💻 Author

Created with ❤️ for families who want to eat better.

---

<p align="center">
  <b>🍽️ FamFood - Plan • Cook • Enjoy with Family</b>
</p>
